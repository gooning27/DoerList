﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoerList
{
    public partial class DailyTaskUI : Form
    {
        public DailyTaskUI()
        {
            InitializeComponent();
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
        }
        private void btnRemoveAll_Click(object sender, EventArgs e)
        {
        }
        private void btnReloadDailyTasks_Click(object sender, EventArgs e)
        {
        }

        private void listBoxTasks_Click(object sender, EventArgs e)
        {
        }
        private void chkDaily_Click(object sender, EventArgs e)
        {
        }



    }
   }
